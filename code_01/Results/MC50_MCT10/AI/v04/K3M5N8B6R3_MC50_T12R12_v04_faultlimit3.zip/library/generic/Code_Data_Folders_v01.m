function [CodeFolder,DataFolder]=Code_Data_Folders_v01
CodeFolder=[pwd '\'];
cd '..\data\'
DataFolder=[pwd '\'];