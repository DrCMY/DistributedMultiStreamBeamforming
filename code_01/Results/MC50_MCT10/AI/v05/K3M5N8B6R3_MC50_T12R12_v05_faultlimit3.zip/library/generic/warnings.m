function warnings
disp('0) Please change the Matlab directory to "code_X" folder')
disp('0) If this is the first time you are running the codes, please add the "code_X" and "data" folders with their subfolders to your Matlab')
disp('2) Please remove any file in the folders that will not be used, e.g., remove the old versions of your codes')