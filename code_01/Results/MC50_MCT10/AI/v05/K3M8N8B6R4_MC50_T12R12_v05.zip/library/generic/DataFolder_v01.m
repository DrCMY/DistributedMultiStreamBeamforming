function DataFolder=DataFolder_v01
CodeFolder=[pwd '\'];
cd '..\data\'
DataFolder=[pwd '\'];
cd(CodeFolder)